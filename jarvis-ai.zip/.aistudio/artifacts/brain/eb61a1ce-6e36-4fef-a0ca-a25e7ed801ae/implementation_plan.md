# JARVIS AI – Full-Stack Web Conversion & Deployment Plan

This plan diagnoses why the web preview URL is currently unresponsive and defines the architecture to convert the existing **JARVIS AI** Android application into a complete, responsive, production-ready web application with secure server-side Google Gemini integration and multi-platform cloud deployment support.

## User Review & Critical Decisions

> [!IMPORTANT]
> **Root-Cause Diagnosis (Why the Web URL Keeps Loading / Fails to Open):**
> Inspection of the workspace confirms this repository is currently a native **Android Gradle/Kotlin/Jetpack Compose** project (`MainActivity`, `JarvisViewModel`, Room database, Android `SpeechRecognizer`, `TextToSpeech`). There is no web frontend entry point, no `package.json`, and no HTTP/Cloud Run web server listening on `PORT` (`0.0.0.0`). Because the AI Studio container is configured as an Android build environment, the Cloud Run URL cannot serve a browser app until a full-stack web application is built and deployed to a web runtime.

Since clarifying questions were skipped, the plan proceeds with these recommended defaults:

- **Web Stack**: **React + Vite + TypeScript** frontend paired with a **Node.js + Express** backend server using the official `@google/genai` SDK.
- **Workspace Organization**: Preserve the existing Android Gradle project intact at the workspace root (preventing Android build breakage) and generate the complete, self-contained full-stack web application inside a dedicated web workspace directory ready to run locally or export for deployment.
- **Deployment Targets**: Include production-ready configuration for **Google Cloud Run** (`Dockerfile`, `PORT` binding on `0.0.0.0`, `/health` endpoint), **Vercel**, **Netlify**, and **Firebase Hosting**.

---

## 1. Overview & Core Concept

- **What It Does**: Recreates every screen, workflow, and visual detail of the JARVIS Android app inside a browser-native experience accessible from Chrome, Edge, Firefox, and mobile browsers—without requiring an APK installation.
- **Target Audience / Persona**: The owner ("Sir") operating JARVIS across desktop monitors, tablets, and mobile phones with real-time voice, text, multi-agent delegation, security auditing, plugin execution, and persistent local memory.
- **Key Value**: Delivers a zero-install, cross-platform JARVIS command center backed by a secure server-side Gemini proxy, eliminating client-side API key exposure and infinite loading states.

---

## 2. User Experience & Visual Design

### 2.1 User Flows & Screen Parity

1. **Interactive Biometric Opening Screen**:
   - Features the **Quantum AI Core** with multi-axis gyroscopic orbital rings, coronal energy flares, holographic grid lines, and subtle cosmic starfield dust.
   - Includes the **Touch & Hold Biometric Verification Pad** (mouse-down / touch-start calibration ring from 0% to 100% with laser sweep) plus an instant **Bypass Scan** and **Activate Voice Matrix** shortcut.
   - Guarantees non-blocking entry with zero stuck loading screens.
2. **Cosmic Command Dashboard**:
   - Responsive dark-glass HUD displaying real browser & connection telemetry (online/offline status, memory hints when exposed by browser, battery API where supported, screen/viewport metrics, local clock), DEFCON security badge, specialized agent shortcuts, and the 10-module launcher grid.
3. **10 Functional Feature Modules (1:1 Parity with Android)**:
   - **Neural Chat**: Multi-agent switcher (`JARVIS`, `VERONICA`, `DUM-E`, `FRIDAY`, `HOMER`), real-time SSE streaming from the backend Gemini endpoint, conversation history, speech playback, and transparent connection/API status banner (`Online`, `Connecting`, `Offline`, or `API Key Missing`).
   - **Voice Matrix HUD**: Browser Web Speech API (`SpeechRecognition` / `webkitSpeechRecognition`) + `Web Audio API` live microphone visualizer + `SpeechSynthesis` TTS with interrupt/stop controls and English/Hindi/Gujarati language selection.
   - **Multi-Agent Hub**: Intent routing visualization, direct agent handoff, and live inter-agent collaboration log stream.
   - **Security Audit Center**: Automated browser security posture checks (HTTPS/TLS verification, API key isolation, CSP/permission audit, audit log anomaly analysis), DEFCON 5–1 toggle, Emergency Lockdown mode, and Master PIN verification gate.
   - **System Telemetry & CLI**: Live browser/device telemetry gauges, volume/speech rate controls, quick external link launchers, and an interactive Stark Terminal supporting `help`, `sysinfo`, `diagnostics`, `ping`, `defcon`, `agents`, `clean-cache`, and `clear`.
   - **Plugin Matrix**: Standardized TypeScript plugin interface with working **Trello & Asana Kanban Board** (add card, advance status columns), **GitHub DevOps Sentinel**, and **Home Assistant Bridge** tool runners.
   - **Long-Term Memory Vault**: Persistent browser storage (IndexedDB / `localStorage`) with search, category tagging (`PREFERENCE`, `PROJECT`, `INSTRUCTION`, `FACT`), add, and delete—automatically injected into Gemini prompts.
   - **Executive Planner**: Persistent task, schedule, and reminder manager with priority badges, completion toggles, and FRIDAY daily briefing integration.
   - **Stark Smart Home**: Interactive room/device controls and scene presets (clearly labeled as local simulation unless connected to a configured Home Assistant webhook).
   - **Vision Scanner**: Real `navigator.mediaDevices.getUserMedia` live webcam feed (with explicit permission handling and graceful fallback if no camera exists), frame snapshot capture, and real multimodal image analysis via Gemini Vision.

### 2.2 Visual Identity & Theme

- **Aesthetic Direction**: Classic Stark holographic cyan and electric blue precision HUD layered over an infinite deep-space obsidian backdrop.
- **Color Tokens**:
  - `--bg-obsidian`: `#02040A` (primary canvas)
  - `--surface-glass`: `rgba(13, 21, 39, 0.85)` with `1px solid #1E293B` subtle glowing borders
  - `--accent-cyan`: `#00F0FF` and `--accent-ice`: `#7DD3FC`
  - `--accent-blue`: `#0099FF` and `--accent-violet`: `#7C3AED`
  - `--status-emerald`: `#10B981`, `--status-amber`: `#FBBF24`, `--status-crimson`: `#F43F5E`
  - `--text-silver`: `#F8FAFC` and `--text-muted`: `#94A3B8`
- **Typography**: Clean geometric display typography (`Orbitron` / `Space Grotesk`) paired with crisp monospace telemetry (`JetBrains Mono`) and readable body copy (`Inter`).
- **Accessibility & Motion**: Full keyboard focus rings, ARIA labels, reduced-motion toggle (`prefers-reduced-motion` + in-app setting), and adaptive sidebar/bottom navigation across mobile, tablet, and desktop viewports.

---

## 3. Key Product Decisions & Trade-Offs

- **Backend Proxy for Gemini (`Node.js + Express`) vs. Client-Side Key**:
  - *Chosen*: Dedicated Express API server using `@google/genai` (`gemini-2.5-flash`) with SSE streaming, CORS handling, request timeouts, and `/health` endpoint.
  - *Why*: Keeps `GEMINI_API_KEY` strictly on the server, prevents credential leakage in browser bundles, and satisfies Google Cloud Run requirements (`0.0.0.0:$PORT`).
- **Android-to-Web API Replacements**:
  - *Room SQLite* → Browser `localStorage` / IndexedDB persistence wrapper with instant hydration and zero blocking initialization.
  - *Android `SpeechRecognizer` & `TextToSpeech`* → Web `SpeechRecognition` + `window.speechSynthesis` with graceful capability detection banner on unsupported browsers.
  - *Android `BatteryManager` / `ActivityManager`* → Real browser APIs (`navigator.onLine`, `navigator.getBattery` where available, `navigator.deviceMemory`, `performance.memory` where exposed) without fabricating fake hardware readings.
  - *Android Camera Intent* → HTML5 `MediaDevices.getUserMedia()` live camera preview + Canvas frame capture sent to Gemini multimodal analysis.
- **Honest Capability Signaling**:
  - Hardware OS control (Windows shutdown/arbitrary shell) and Home Assistant hardware calls are explicitly marked as simulated/configurable bridges when no external companion endpoint is provided, rather than pretending they control the host OS.

---

## 4. Technical Architecture & Data Strategy

```
┌──────────────────────────────────────────────────────────────────────────┐
│                        BROWSER CLIENT (React + Vite + TS)                │
│                                                                          │
│  ┌─────────────────────┐   ┌──────────────────────────────────────────┐  │
│  │ Cosmic Opening &    │   │ Command Dashboard & 10 Feature Modules   │  │
│  │ Biometric Hold Pad  │──▶│ (Chat, Voice, Agents, Security, CLI,     │  │
│  │ + HTML5 Quantum     │   │  Plugins, Memory, Planner, Home, Vision) │  │
│  │   Canvas Core       │   └────────────────────┬─────────────────────┘  │
│  └─────────────────────┘                        │                        │
│                                                 ▼                        │
│  ┌──────────────────────────────────┐   ┌─────────────────────────────┐  │
│  │ Persistent Browser Store         │   │ Web Hardware & Media Layer  │  │
│  │ (Memories, Chats, Tasks, Logs)   │   │ (Web Speech, MediaDevices)  │  │
│  └──────────────────────────────────┘   └─────────────────────────────┘  │
└───────────────────────────────────────┬──────────────────────────────────┘
                                        │ HTTPS / SSE (Fetch Stream)
                                        ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                 NODE.JS EXPRESS SERVER (0.0.0.0:$PORT)                   │
│                                                                          │
│  • GET  /health           -> Server uptime, Gemini key status, version   │
│  • POST /api/chat/stream  -> SSE streaming via @google/genai             │
│  • POST /api/vision       -> Multimodal image + prompt analysis          │
│  • Static Asset Serving   -> Serves built Vite React production bundle   │
└───────────────────────────────────────┬──────────────────────────────────┘
                                        │ Server-Side Secret (GEMINI_API_KEY)
                                        ▼
┌──────────────────────────────────────────────────────────────────────────┐
│                       GOOGLE GEMINI API (gemini-2.5-flash)               │
└──────────────────────────────────────────────────────────────────────────┘
```

### Interactive State & Error Recovery Strategy
- **Zero Infinite Loading**: Initial app mount renders immediately from synchronous state; backend connectivity is checked via `/health` with an explicit 5-second `AbortController` timeout and retry button, transitioning cleanly between `Connecting`, `Online`, `Missing API Key`, and `Offline` states.
- **Streaming Resilience**: Chat streaming uses `fetch` + `ReadableStream` SSE parsing with per-request cancellation (`Stop Generating`), 60-second timeout protection, and clear user-facing error cards with a **Retry** action if the backend or Gemini API returns an error.
- **Deployment Readiness**: Includes a multi-stage `Dockerfile` for Google Cloud Run (binding `0.0.0.0` on `process.env.PORT`), `vercel.json`, `netlify.toml`, `firebase.json`, `.env.example`, and complete local & production build/run instructions.
