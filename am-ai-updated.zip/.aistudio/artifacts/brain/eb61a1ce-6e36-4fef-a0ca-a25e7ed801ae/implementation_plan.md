# AM AI Android Full Feature Repair & Web Cosmic HUD Parity

Upgrade the Android application so every AI, voice, media, automation, and telemetry feature works reliably using the deployed Vercel backend with automatic direct API fallback, while bringing the entire Android interface, Cosmic HUD, themes, layouts, and missing studios up to full parity with the Web application.

## User Review & Critical Decisions

> [!IMPORTANT]
> Your Turn 1 answers locked in the four core product decisions below. Please review the plan details and approve to begin implementation.

- **Confirmed Decision 1 (Scope)**: Fix all broken Android backend, AI, voice, and lint paths **and** bring Android UI and modules to complete parity with the Web app without deleting existing local features.
- **Confirmed Decision 2 (Connectivity)**: Connect Android primarily to the deployed Vercel backend with **automatic direct multi-provider API fallback** (Gemini Free -> Groq Free -> OpenRouter Free) and clean offline recovery when remote endpoints fail, time out, or lack credentials.
- **Confirmed Decision 3 (Missing Modules)**: Port **all missing Web modules** natively to Android (`Multi-AI Brain Control Center`, `Research & Document Studio`, `Smart Automation Hub`, `Lyria Music Core`, `Orbital Aegis 3D Game`, `ULTRON Holographic AI`, `Universal Website Launcher / Browser`, and `Unified Ecosystem Diagnostics & Remote Config`).
- **Confirmed Decision 4 (Visual Parity)**: Match the Web **Cosmic HUD** natively in Jetpack Compose, including the interactive **3D Wireframe Hologram Sphere**, **12-Sector Arc Reactor** switcher, **4 HUD Theme Presets** (including daylight `Light HUD`), and **Dashboard Layout Modes** (`Cosmic`, `Compact`, `Focus`, `Classic`).
- **Recommended Default (Remote Configuration & Branding)**: Unify remaining legacy greetings/titles on Android to the warm `AM AI` peer persona (removing hardcoded `"Sir"` and legacy codenames), and expose a user-editable Production Backend URL override plus 60-second `/api/config` & `/api/health` sync inside Settings & Diagnostics.

---

## 1. Overview & Core Concept

- **What It Does**: Eliminates every single point of failure currently breaking Android AI streaming, briefings, memory extraction, voice synthesis, natural reminder parsing, and YouTube WebView compilation, while expanding Android from 15 legacy screens into the full 22-module synchronized AM AI ecosystem found on Web.
- **Target Audience / Persona**: Power users, students, engineers, and everyday owners switching seamlessly between Web desktop and Android mobile who expect identical visual polish, unified AM AI personality, shared multi-provider routing telemetry, and uninterrupted operation across mobile networks and offline environments.
- **Key Value**: One coherent, dependable AI companion where chat, voice, research, music synthesis, automation, 3D holographic interfaces, and multi-agent coordination behave consistently on both platforms—even if the remote Vercel proxy temporarily hits a rate limit, cold start, or missing key.

---

## 2. User Experience & Visual Design

### Visual Identity & Theme

- **Aesthetic Direction**: Retro-futuristic orbital cockpit ("Cosmic HUD") paired with clean glassmorphic surface hierarchy and high-contrast sci-fi telemetry instrumentation—avoiding generic flat cards while keeping mobile touch ergonomics (minimum `48dp` targets, edge-to-edge safe insets).
- **Color Palette & Mood (Full 4-Preset Web Parity)**:
  - *Cosmic Default* (Primary): Deep orbital obsidian void (`#02050B`) with glowing electric cyan (`#22D3EE`) and indigo (`#6366F1`) accents, translucent slate HUD surfaces, and luminous `1dp` plasma hairline borders.
  - *Arc Cyan*: High-contrast reactor teal (`#06B6D4` / `#38BDF8`) over midnight steel (`#030914`).
  - *Stark Gold*: Warm tactical amber and titanium gold (`#F59E0B` / `#FBBF24`) over dark graphite (`#090705`).
  - *Light HUD*: Clean ceramic daylight posture (`#F1F5F9` background, `#FFFFFF` frosted surface panels, `#0F172A` high-contrast typography, `#0284C7` cobalt accent) ensuring all theme tokens derive cleanly from `MaterialTheme.colorScheme` instead of hardcoded dark hex backgrounds.
- **Typography & Hierarchy**: Geometric sci-fi display styling with wide uppercase tracking (`0.12em–0.16em`) for HUD telemetry labels and module headers, paired with crisp tabular monospace readouts for live battery, RAM, latency, API switches, and token/provider metrics, and clean sans-serif body typography for chat, reports, and long-form output.
- **Component Styling & Layout**:
  - **Cockpit Header & Module Dock**: Compact single-row status badge (`SHARED AI STATE`: `IDLE`, `LISTENING`, `THINKING`, `SPEAKING`, `OFFLINE`), theme/layout quick switchers, active provider/model chip, and scrollable horizontal Module Dock Ribbon + Left/Edge Navigation Drawer covering all 22 modules.
  - **Central Interactive Core**: Toggleable hero centerpiece offering both a **3D Wireframe Geodesic Hologram Sphere** (real-time 3D rotation, drag inertia, audio/state-reactive pulse) and an **Interactive 12-Sector Arc Reactor** (rotating segmented rings with sector readout) positioned cleanly inside three-wing `Cosmic`, single-column `Compact`, minimalist `Focus`, or vertical `Classic` dashboard layouts.
  - **5-Button Chamfered Action Strip**: Tactile hardware-inspired quick controls (`STBY`, `DIAG`, `SYNC`, `CLSC`, `LOCK`) wired to genuine voice standby, hardware diagnostics, backend config sync, layout toggle, and privacy/audio lock actions.

### Key User Flows

1. **Dashboard Cockpit & Core Interaction**: User launches into the updated `AM AI` Cosmic Cockpit; rotating the 3D Hologram Sphere or tapping sectors of the 12-Sector Arc Reactor triggers haptic/visual state changes, launches voice capture, cycles presets, or opens quick modules (`Chat`, `Voice HUD`, `Research`, `Multi-AI`, `Media`, `Automation`).
2. **Resilient AI Chat, Multimodal & Briefings**: Sending text, voice, images, PDFs, or summarization/briefing requests attempts the configured production Vercel backend first and transparently fails over to direct zero-cost keys (`Gemini Free` -> `Groq Free` -> `$0 OpenRouter`) or local on-device fallback whenever the backend is unreachable or returns an upstream error—never dead-ending on a proxy error.
3. **New Studio & Module Parity Flows**:
   - *Multi-AI Brain Control Center*: Inspect 11+ free providers, run real connectivity tests (not key-existence checks), trigger 14 specialist agents, inspect collaboration traces, and adjust router/cooldown policies.
   - *Research & Document Studio*: Run live web-grounded research queries, upload local PDF/DOCX/TXT/Markdown documents for chunked Q&A, and generate exportable structured executive/study/code reports.
   - *Smart Automation Hub*: Launch curated safe websites and quick-action workflows (note creation, natural reminders, prompt dispatch, authorized drafts) with an explicit confirmation modal guard and persistent automation audit log.
   - *Lyria Music Core*: Compose instrumentals or vocal/lyric tracks via clip or pro prompts, browse generated library cards, and control live media playback.
   - *Orbital Aegis 3D Game*: Play a 60fps space combat arena with touch-drag spacecraft steering, firing/dash controls, wave/boss HUD bars, difficulty/atmosphere toggles, and optional generated soundtrack playback.
   - *ULTRON Holographic AI*: Switch between 5 morphing 3D geometric holographic avatars (`Sphere`, `Torus`, `Polyhedron`, `Helix`, `Lattice`), engage bilingual voice loops, and tap instant STEM/coding/math quick prompts.
   - *Media & Universal Browser*: Switch smoothly between the repaired YouTube Player/Search tab (with fixed WebView JavaScript bridge) and the curated Browser / Safe Website Launcher tab.
   - *Unified Ecosystem Diagnostics & Sync*: View live backend reachability, API compatibility version, masked provider key statuses, active model/voice config, trigger manual sync, or override the backend base URL without rebuilding the APK.

### Interactive Feedback & Motion

- **Unified Shared AI State Feedback**: The top status pill, 3D Hologram Sphere velocity/glow, 12-Sector Arc Reactor rotation, and Voice HUD equalizer continuously reflect the real-time state machine (`IDLE`, `LISTENING`, `THINKING`, `SPEAKING`, `OFFLINE`).
- **Clear Error & Offline Boundaries**: Network disconnections cleanly switch the HUD pill to `OFFLINE`, queue sync-eligible notes/tasks/memories, show non-blocking failover banners when direct API rescue activates, and preserve full access to local screens and history.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 (Backend-First with Transparent Direct API Failover)**:
  - *Chosen Approach*: Keep the deployed Vercel backend as primary orchestration layer, but automatically invoke Android's existing direct zero-cost Multi-Provider Router (`Gemini Free` -> `Groq Free` -> `OpenRouter Free`) across **all** AI surfaces (streaming chat, multimodal vision, conversation summary, memory extraction, natural reminders, daily briefings, research, music, and ULTRON) whenever the backend is unreachable, unconfigured, or errors with 404/5xx/timeout.
  - *Why*: Fixes the single biggest blocker on Android where setting `BACKEND_URL` caused every feature to fail if the remote server lacked a route, key, or timed out on cold start.
  - *Alternatives Considered*: Requiring backend-only calls with no fallback (rejected—leaves mobile broken whenever backend routes lag behind) or bypassing the backend entirely (rejected—breaks Web/Android centralized synchronization).
- **Decision 2 (Unified Persistent Remote Config Sync Without APK Rebuilds)**:
  - *Chosen Approach*: Wire versioned `/api/config` and `/api/config/test` endpoints on the Express backend backed by persistent storage (never leaking raw API keys), and add startup + 60-second background polling + manual `SYNC` trigger + cached offline fallback on Android alongside user-overrideable Backend URL and theme/layout preferences in DataStore.
  - *Why*: Lets model selections, voice settings, feature flags, and fallback providers update live across Web and Android from one central place.
  - *Alternatives Considered*: Hardcoding config solely via build-time environment variables (rejected—forces new APK installs for minor config changes).
- **Decision 3 (Native Jetpack Compose 3D Projection vs. Embedded WebView for Cosmic Visuals & Orbital Game)**:
  - *Chosen Approach*: Render the 3D Hologram Sphere, 12-Sector Arc Reactor, ULTRON 5-shape morphing lattice, and Orbital Aegis 3D arena natively on Jetpack Compose `Canvas` using genuine 3D matrix projection and smooth frame timing rather than wrapping Three.js in slow WebViews.
  - *Why*: Instant zero-jank startup, offline readiness, tight integration with Android voice telemetry and touch gestures, and full reactivity to the active Compose `ColorScheme` (including `Light HUD`).
  - *Alternatives Considered*: Embedding HTML/Three.js WebViews inside Compose screens (rejected—heavy memory footprint, sluggish theme transitions, and touch-focus conflicts).
- **Decision 4 (Zero-Tolerance Cleanup of Legacy Identity & Broken Lint Bridges)**:
  - *Chosen Approach*: Remove hardcoded `"Sir"` memory seeds, system instructions, canonical command replies, and legacy header strings in favor of `AM AI`'s warm peer persona, and instantiate the YouTube WebView JavaScript bridge directly inside the native view factory so Android Lint passes with zero errors.
  - *Why*: Prevents contradictory prompt injection back into conversations and unblocks clean release/debug lint verification.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌────────────────────────────────────────────────────────────────────────────┐
│                   VERCEL EXPRESS BACKEND (Single Source of Truth)          │
│                                                                            │
│  ┌─────────────────────┐  ┌──────────────────┐  ┌───────────────────────┐  │
│  │ Persistent Config & │  │ Chat / Brain /   │  │ Research / Lyria /    │  │
│  │ Admin Auth Store    │  │ Voice / Briefing │  │ YouTube Search API    │  │
│  │ (/api/config, test) │  │ SSE & REST       │  │ (/api/research, etc.) │  │
│  └──────────┬──────────┘  └────────┬─────────┘  └──────────┬────────────┘  │
└─────────────┼──────────────────────┼───────────────────────┼───────────────┘
              │ HTTPS Poll (60s/Sync) │ SSE / REST            │ Search / Media
              ▼                      ▼                       ▼
┌────────────────────────────────────────────────────────────────────────────┐
│               ANDROID DATA & RESILIENCE LAYER (Offline-Capable)            │
│                                                                            │
│  ┌──────────────────────┐    ┌──────────────────────────────────────────┐  │
│  │ Sync & Config Engine │    │ Resilient AI Orchestrator                │  │
│  │ • Startup + 60s poll │    │ 1. Primary: Backend URL (Runtime/Build)  │  │
│  │ • Version check      │───▶│ 2. Auto-Failover: Direct Free Providers  │  │
│  │ • Cached JSON Store  │    │    (Gemini -> Groq -> $0 OpenRouter)     │  │
│  └──────────┬───────────┘    │ 3. Offline: Local Vault + Guidance       │  │
│             │                └─────────────────────┬────────────────────┘  │
│             ▼                                      ▼                       │
│  ┌──────────────────────┐    ┌──────────────────────────────────────────┐  │
│  │ DataStore & Room DB  │    │ Unified Shared AI State & Voice Manager  │  │
│  │ • 4 HUD Themes       │    │ • idle / listening / thinking / speaking │  │
│  │ • Layout Modes       │    │ • Neural TTS + Native Fallback (API >=26)│  │
│  │ • Vault / Logs       │    └─────────────────────┬────────────────────┘  │
└─────────────┼──────────────────────────────────────┼───────────────────────┘
              │                                      │
              ▼                                      ▼
┌────────────────────────────────────────────────────────────────────────────┐
│               JETPACK COMPOSE COSMIC HUD & 22 SYNCHRONIZED MODULES         │
│                                                                            │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │ Cosmic Cockpit Dashboard (Cosmic / Compact / Focus / Classic)        │  │
│  │ • Top Status & Module Dock Ribbon + 5-Button Chamfered Action Strip  │  │
│  │ • Interactive 3D Geodesic Sphere <-> 12-Sector Arc Reactor Switcher  │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│  ┌─────────────────────────┐  ┌─────────────────────┐  ┌────────────────┐  │
│  │ Core Assistants & Tools │  │ Newly Ported Studios│  │ Diagnostics &  │  │
│  │ • Chat & Multimodal     │  │ • Multi-AI Control  │  │ System Control │  │
│  │ • Voice HUD & ULTRON 3D │  │ • Research Studio   │  │ • Ecosystem    │  │
│  │ • YouTube + Web Browser │  │ • Automation Hub    │  │   Diagnostics  │  │
│  │ • Tasks / Notes / Vault │  │ • Lyria Music Core  │  │ • Config Sync  │  │
│  │ • Smart Home / Terminal │  │ • Orbital Aegis 3D  │  │ • 4 HUD Themes │  │
│  └─────────────────────────┘  └─────────────────────┘  └────────────────┘  │
└────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **Remote Ecosystem Config Snapshot**: Stores `version`, `minAndroidVersion`, `minWebVersion`, `activeProvider`, `defaultModel`, `fallbackProviders`, `voiceSettings`, `featureFlags`, and masked provider readiness booleans (never storing or transmitting raw secret keys). Persisted to local preferences cache on Android for instant startup and offline continuity.
- **UI Appearance & Navigation State**: Extends DataStore preferences with `hudThemePreset` (`COSMIC_DEFAULT`, `ARC_CYAN`, `STARK_GOLD`, `LIGHT_HUD`), `dashboardLayoutMode` (`COSMIC`, `COMPACT`, `FOCUS`, `CLASSIC`), `coreVisualizerMode` (`HOLOGRAM_3D`, `ARC_REACTOR`), and optional user-configured `customBackendUrl` override.
- **Module-Specific Domain States**:
  - *Multi-AI Control Center*: Provider connectivity states (`CONNECTED`, `ERROR`, `COOLDOWN`, `UNCONFIGURED`), specialist agent roster metrics, active coordination step stream, and router policy settings.
  - *Research Studio*: Grounded web search results with citations, parsed document chunks (PDF/TXT/MD/DOCX via `OpenDocument`), Q&A turn history, and generated report templates.
  - *Automation Hub*: Editable quick-action cards, external website approval validations, pending confirmation state, and persistent `AutomationHistory` log records.
  - *Lyria Music & Orbital Game*: Generated audio track metadata/base64 store, active playback state, and 60fps mutable game simulation frame state (`phase`, `score`, `wave`, `shield`, `beacon`, `bossHp`, `atmosphere`, `difficulty`).
  - *Memory & Persona Hygiene*: Automatic migration check ensuring seeded/default owner preferences use warm peer `AM AI` guidance rather than `"Sir"`.

### Interactive Component & State Mapping

- **Dashboard Core & Action Strip**: Tapping `3D HOLOGRAM` / `ARC REACTOR` swaps the animated center projection; tapping `STBY` toggles voice capture/speech; `DIAG` launches Ecosystem Diagnostics; `SYNC` pulls `/api/config` & `/api/health` immediately; `CLSC` cycles layout mode; `LOCK` mutes audio output cleanly.
- **Theme & Layout Selectors**: Selecting any of the 4 HUD Theme Presets updates `MaterialTheme.colorScheme` reactively across every Compose screen (including flipping surface/text contrast cleanly for `Light HUD`).
- **YouTube Player Bridge & Browser Tabs**: Extracting the WebView JavaScript bridge creation cleanly inside the Android View factory resolves the static `@JavascriptInterface` lint error, while switching to the `Websites` tab displays searchable approved destinations and a safe URL bar with external browser fallback.
- **Resilient AI Requests**: Every streaming and non-streaming AI action follows a single shared pipeline: validate connectivity -> call backend endpoint (with Bearer token if present) -> on HTTP 404/5xx/network failure/empty body, log telemetry event and transparently retry via the direct multi-provider client -> emit clear diagnostic error state only when all configured channels fail.

### Key Verification Targets

- Express backend unit tests (`npm --prefix web run test`) and Web production bundle build (`npm --prefix web run build`) pass with remote config sync and `/api/config` routes intact.
- Android unit & Robolectric suites (`gradle :app:testDebugUnitTest`) verify backend-to-direct failover, config polling/caching, theme & layout persistence, memory sanitization, and new module state flows.
- Android full build (`compile_applet`) and static analysis (`lint_applet`) succeed with **0 errors**, confirming the YouTube `@JavascriptInterface` issue and all new Compose UI components compile cleanly.
