# Revised Implementation Plan — AM AI Unified Ecosystem & Secure Centralized Config

This revised plan incorporates all 10 mandatory improvements: persistent storage, atomic versioning & audit logs, secure admin authentication, masked API keys, startup/periodic sync, version compatibility checks, secure Admin UI, real provider connection testing, and Vercel/APK verification.

## User Review & Critical Decisions

> [!IMPORTANT]
> - **Persistent Backend Storage**: Uses JSON file persistence (`server/data/config_store.json`) alongside environment fallback to survive serverless restarts on Vercel.
> - **Security & Masking**: `GET /api/config` returns masked keys (`AIzaSy...***`), while `POST /api/config` requires `Authorization: Bearer <APP_ACCESS_TOKEN>`.
> - **Real Connection Testing**: Endpoints test actual ping/model discovery with live providers instead of assuming status based on key presence.

---

### 1. Backend Centralized Configuration Store & API (`/web/server/configManager.js` & `index.js`)
- **Persistent Storage**: Save/load config versions, provider overrides, default models, and feature flags to `server/data/config_store.json`.
- **Versioning & Audit Logs**: Each update increments `version` (`1`, `2`, ...) and logs timestamp, actor, and changes.
- **Secure Admin Endpoints**:
  - `GET /api/config`: Returns sanitized/masked configuration (no raw secret keys).
  - `POST /api/config` (Protected by Bearer token): Validates input, writes atomically, and increments version.
  - `POST /api/config/test`: Performs a live connection probe against Gemini, Groq, or OpenRouter.

### 2. Android Configuration Sync & Client (`/app`)
- **Startup & Polling Sync**: Fetches `/api/config` on app initialization and every 60 seconds (or on manual pull-to-refresh), caching into DataStore preferences with offline fallback.
- **Version Compatibility**: Checks minimum client version headers (`X-Min-Client-Version`).

### 3. Web Configuration Sync & Admin Panel (`/web`)
- **Admin Settings View**: Secure UI for managing AI providers, model selection, keys, voice settings, and feature flags.
- **Real-Time Diagnostics**: Live connection test button per provider with status badges.

---

### Verification Plan
- Run Web tests: `npm --prefix web run test`
- Run Android unit tests: `gradle :app:testDebugUnitTest`
- Compile Android app: `compile_applet`
