# Changelog — JARVIS AI (Release 3.0)

## [Voice Upgrade] — Soft Expressive Female Voice (Laila-Inspired, Web & Android)
- **Backend Neural TTS (`/api/tts/synthesize`, `/api/tts/voices`)**: Added free server-side neural female TTS powered by `msedge-tts` (`hi-IN-SwaraNeural`, `en-IN-NeerjaExpressiveNeural` -> `en-IN-NeerjaNeural` -> `en-US-AvaMultilingualNeural`, `en-GB-SoniaNeural`, `gu-IN-DhwaniNeural`) with XML/SSML escaping, gentle ~0.90x pacing, expressive rise/fall prosody, inter-sentence breath pauses (`260–320ms`), and bounded in-memory caching—requiring zero API keys.
- **Web Voice Engine & Test Controls**: Upgraded `WebVoiceEngine`, `femaleVoiceCatalog.js`, `DEFAULT_SETTINGS`, `VoiceHudView`, and `SettingsView` to play neural expressive audio with seamless bilingual `speechSynthesis` fallback while preserving wake-word detection, STT, audio ducking, pause/resume/stop, and existing HUD/theme layout. Added `TEST HI` and `TEST EN` voice audition buttons alongside `TEST VOICE`.
- **Android Voice Manager & Settings**: Upgraded `JarvisVoiceManager`, `SpeechFormatter`, `JarvisLanguage`, `JarvisPreferencesRepository`, `JarvisViewModel`, and `SettingsScreen` to support online backend neural TTS via `MediaPlayer` with automatic fallback to female-ranked bilingual Android `TextToSpeech` and compact `HI` / `EN` voice test buttons inside the existing calibration card.

## [Phase 1] — Futuristic UI + 3D Hologram + Shared AI State System
- **Shared AI State System**: Added `SharedAiStateContext` and pure `sharedAiState.js` state derivation (`idle` | `listening` | `thinking` | `speaking`) driven exclusively by real mic, AI request, and speech synthesis events, syncing `data-ai-state` and `--am-ai-energy` across the HUD.
- **Interactive Three.js 3D Hologram**: Added `HologramSphere3D` featuring a dual geodesic wireframe sphere, 3 counter-rotating gyroscopic rings, seeded particle cloud, smooth mouse/touch drag rotation with inertia, mobile pixel-ratio/particle throttling, WebGL fallback, and `prefers-reduced-motion` safety.
- **Selectable HUD Theme Presets**: Preserved Cosmic Default (`#02050B`) and added `Arc Cyan`, `Stark Gold`, and `Light HUD` presets with Header HUD quick switcher and Settings persistence alongside existing Dark/Light and 5 Accent Themes.
- **Zero Regression**: Preserved `AMReactor` (12-sector click controls via `3D HOLOGRAM` / `ARC REACTOR` toggle), `QuantumCoreCanvas`, and all 21 existing screens and APIs.

## [3.0.0] — Features 1–12, Cloud Run Deployment Hardening & Full Test Suite

### Added — Android (`/app`) & Web (`/web`) Productivity, AI & UX
- **Multi-Session Chat & Persistence**: Room `chat_sessions` (v2) + `localStorage` multi-session sidebar drawer, session search, create/rename/delete, and empty/loading states.
- **Settings Persistence**: Jetpack DataStore (`SettingsPreferences`) on Android and `localStorage` preferences + `sessionStorage` optional access token on Web (language, AI agent, voice selection/speed/pitch, auto-speak, web search toggle, memory extraction toggle, accent color, API connection status).
- **Rich Chat Controls**: Markdown rendering, syntax-highlighted code blocks with copy button, regenerate reply, edit & resend prompt, and stop generation / abort stream.
- **Auto Memory Extraction + Deduplication**: Automated durable-fact extraction (`MemoryDeduplicator.kt` / `memoryDedupe.js`) with toast notification & 1-click Undo.
- **Hands-Free Continuous Voice & Local Commands**: Auto-restarting voice loop with `VoiceCommandParser.kt` & `voiceCommands.ts` for instant offline/local controls (`stop`, `open security`, `toggle lockdown`, `what's my battery`, `new chat`).
- **Smart Natural-Language Reminders**: Deterministic + Gemini JSON parser (`ReminderParser.kt` / `reminderParser.js`) scheduling real Android `AlarmManager` + `ReminderBroadcastReceiver` notifications (Room v3 `triggerAtMillis`) and browser notifications.
- **Vault Export & Validated Import**: JSON (`jarvis_backup_v1`) and Markdown backup generation plus schema-validated JSON import preview with duplicate skipping (`JarvisBackupManager.kt` / `backup.ts`).
- **Document & Image Q&A (Multimodal)**: Image, PDF, and text attachment upload & analysis via Gemini on Android (Room v4 attachment columns) and Express `/api/chat/multimodal`.
- **Daily Executive Briefing Card**: Greeting, pending tasks count, live Open-Meteo weather telemetry (with New York fallback), battery/link summary, AI status remark, Refresh, and Read Aloud with 1-hour caching (`briefing.ts`, `/api/briefing`, `MainDashboardScreen.kt`).
- **Custom Agents & Auto-Routing**: Create, edit, and delete custom agents with color picker and comma-separated keyword triggers (`CustomAgentEntity` / Room v5 + `MultiAgentScreen.kt` / `MultiAgentView.tsx`), integrated into chat agent bars.
- **Usage & Insights Dashboard**: KPI tiles and data visualizations using Jetpack Compose `Canvas` (`InsightsScreen.kt`) on Android and pure SVG charts (`InsightsView.tsx`) on Web (7-day activity, agent distribution, task completion donut, voice/text split).

### Security & Cloud Run / GitHub Pages Fixes
- Added `express-rate-limit` (**30 req/min/IP**) and `trust proxy = 1` on `/api/*`.
- Enforced `MAX_PROMPT_CHARS = 8000` validation across all text/multimodal/briefing/reminder/vision/music endpoints.
- Added optional `APP_ACCESS_TOKEN` Bearer auth check using constant-time `crypto.timingSafeEqual`.
- Fixed `/web/Dockerfile` runner stage to include `src/services` alongside `dist/` and `server/`.
- Added `window.history.pushState` / `popstate` SPA routing in `/web/src/App.tsx`, `/favicon.ico` `204` response, and strict `404` for missing `/assets/*` files in `/web/server/index.js`.
- Verified GitHub Pages workflow (`/.github/workflows/deploy-pages.yml`) with dynamic `VITE_BASE_PATH` and `404.html` SPA fallback.

### Upgraded — JARVIS Advanced Command Center Entry Interface (Web & Android)
- **Direct Command Center Entry**: Both Web (`/web/src/App.tsx`) and Android (`JarvisViewModel.kt`) now boot directly into the holographic **Command Center** (`DASHBOARD`), while preserving the **Biometric Lock Gate** (`OPENING`) via header/sidebar access.
- **Sidebar & Navigation**: Left navigation sidebar (desktop + mobile drawer on Web; `ModalNavigationDrawer` on Android) featuring `Command Center`, `AI Core`, `Agents`, `Tasks`, `Calendar`, `Memory`, `Conversations`, `Knowledge Base`, `Tools & Skills`, and `Workflows`, plus collapsible access to all preserved subsystems.
- **Top Header**: Live `SYSTEM STATUS`, auto-updating clock/date bar, interactive Search dialog/bar, Dashboard Layout switcher (`GRID` / `COMPACT` / `FOCUS` on Web), Notifications popover/dialog, Settings button, and `SIR` Operator Profile.
- **Holographic Hero & Telemetry Panels**: Centered glowing `JARVIS / AI CORE` sphere (`QuantumCoreCanvas` / `NeuralIntelligenceCanvas`), `AI Core Overview`, 6 clickable `Active Agents`, `Quick Commands` (`Start New Task`, `Open Calendar`, `Start Voice Chat`, `Run Workflow`), `Live Intelligence Feed`, `Mission Timeline`, honest `System Monitor`, `Memory Insights`, `LLM Status` (`Gemini` live + 8 external providers marked `NOT CONFIGURED`), and sticky `Command Center Bottom Bar` with `AudioWaveVisualizer`, Mic toggle, `TALK TO JARVIS`, and `Executive Briefing`.

### Testing
- Added Web unit & security HTTP tests under `/web/tests/` (`node --test tests/*.test.mjs` — 13/13 passed).
- Added Android JUnit & Robolectric tests (`ReminderParserTest`, `MemoryDeduplicatorTest`, `VoiceCommandParserTest`, `JarvisBackupManagerTest`, `JarvisDatabaseMigrationTest`, `CommandCenterDashboardTest` — 18/18 passed).

