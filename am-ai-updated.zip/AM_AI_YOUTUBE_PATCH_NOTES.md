# AM AI YouTube playback patch

## Changes
- Updated `web/src/services/media/voiceCommandExecutor.ts`.
- Failed YouTube searches no longer call `window.open` / `BrowserActionService.openUrl` automatically.
- A failed search now prepares an in-app fallback message with a clickable YouTube search link.
- Failed video/song search outcomes open the AM AI Media Control view so the fallback is visible.
- Successful video playback outcomes now request navigation to the Media Control view; successful music playback remains on the existing background-player flow.

## Validation performed
- ZIP archive integrity checked before editing.
- Confirmed the old automatic `openUrl(searchRes.fallbackUrl)` call is absent from the play-command failure branch.
- Confirmed fallback and successful-video navigation flags are present.
- TypeScript syntax transpilation of `voiceCommandExecutor.ts`: PASS.
- The existing Node test suite was attempted. 37 tests passed; 12 test files failed to load because dependency installation did not complete (`dotenv` and `msedge-tts` missing).
- `npm ci` timed out in this environment, so a full Vite build, full TypeScript typecheck, live browser playback, Android build, and live YouTube API playback could not be verified here.

## Configuration reminder
For YouTube search, configure `YOUTUBE_API_KEY` on the backend/server environment. Do not put the key in frontend code. Playback still depends on the selected video's embed permissions and YouTube/browser autoplay policy.
