
import { BrowserWindow, screen } from "electron"
import { AppState } from "main"
import path from "node:path"
import { execFile, execSync } from "node:child_process"

const isDev = process.env.NODE_ENV === "development"

const startUrl = isDev
  ? "http://localhost:5180"
  : `file://${path.join(__dirname, "../dist/index.html")}`

export class WindowHelper {
  private mainWindow: BrowserWindow | null = null
  private isWindowVisible: boolean = false
  private windowPosition: { x: number; y: number } | null = null
  private windowSize: { width: number; height: number } | null = null
  private appState: AppState

  // Initialize with explicit number type and 0 value
  private screenWidth: number = 0
  private screenHeight: number = 0
  private step: number = 0
  private currentX: number = 0
  private currentY: number = 0
  private captureMode: boolean = false
  private safariRefocusTimer: NodeJS.Timeout | null = null
  private previousAppBundleId: string | null = null

  constructor(appState: AppState) {
    this.appState = appState
  }

  public setWindowDimensions(width: number, height: number): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) return

    // Get current window position
    const [currentX, currentY] = this.mainWindow.getPosition()

    // Get screen dimensions
    const primaryDisplay = screen.getPrimaryDisplay()
    const workArea = primaryDisplay.workAreaSize

    // Use 75% width if debugging has occurred, otherwise use 60%
    const maxAllowedWidth = Math.floor(
      workArea.width * (this.appState.getHasDebugged() ? 0.75 : 0.5)
    )

    // Ensure width doesn't exceed max allowed width and height is reasonable
    const newWidth = Math.min(width + 32, maxAllowedWidth)
    const newHeight = Math.ceil(height)

    // Center the window horizontally if it would go off screen
    const maxX = workArea.width - newWidth
    const newX = Math.min(Math.max(currentX, 0), maxX)

    // Update window bounds
    this.mainWindow.setBounds({
      x: newX,
      y: currentY,
      width: newWidth,
      height: newHeight
    })

    // Update internal state
    this.windowPosition = { x: newX, y: currentY }
    this.windowSize = { width: newWidth, height: newHeight }
    this.currentX = newX
  }

  public createWindow(): void {
    if (this.mainWindow !== null) return

    const primaryDisplay = screen.getPrimaryDisplay()
    const workArea = primaryDisplay.workAreaSize
    this.screenWidth = workArea.width
    this.screenHeight = workArea.height
    this.step = Math.max(
      Math.round(Math.min(workArea.width, workArea.height) * 0.1),
      120
    )

    
    const isMac = process.platform === "darwin"

    const windowSettings: Electron.BrowserWindowConstructorOptions = {
      width: 400,
      height: 600,
      minWidth: 300,
      minHeight: 200,
      webPreferences: {
        nodeIntegration: true,
        contextIsolation: true,
        preload: path.join(__dirname, "preload.js")
      },
      show: false, // Start hidden, then show after setup
      alwaysOnTop: true,
      frame: false,
      transparent: true,
      fullscreenable: false,
      hasShadow: false,
      backgroundColor: "#00000000",
      focusable: !isMac,
      resizable: true,
      movable: true,
      acceptFirstMouse: true,
      skipTaskbar: true,
      ...(isMac
        ? {
            type: "panel"
          }
        : {}),
      x: 100, // Start at a visible position
      y: 100
    }

    this.mainWindow = new BrowserWindow(windowSettings)
    // this.mainWindow.webContents.openDevTools()
    this.mainWindow.setContentProtection(true)

    if (isMac && this.mainWindow) {
      this.mainWindow.setVisibleOnAllWorkspaces(true, {
        visibleOnFullScreen: true
      })
      this.mainWindow.setHiddenInMissionControl(true)
      this.mainWindow.setAlwaysOnTop(true, "screen-saver")
      this.mainWindow.setMovable(true)
      this.mainWindow.setFocusable(false)
      this.applyPassiveMode()

      try {
        this.mainWindow.setWindowButtonVisibility?.(false)
      } catch (error) {
        console.warn("Unable to hide window buttons:", error)
      }
    } else if (process.platform === "linux") {
      // Linux-specific optimizations for better compatibility
      if (this.mainWindow.setHasShadow) {
        this.mainWindow.setHasShadow(false)
      }
      // Keep window focusable on Linux for proper interaction
      this.mainWindow.setFocusable(true)
      this.mainWindow.setAlwaysOnTop(true)
    } else {
      this.mainWindow.setAlwaysOnTop(true)
    }

    this.mainWindow.loadURL(startUrl).catch((err) => {
      console.error("Failed to load URL:", err)
    })

    // Show window after loading URL and center it
    this.mainWindow.once("ready-to-show", () => {
      if (!this.mainWindow) {
        return
      }
      this.centerWindow()
      this.showMainWindow({ capture: true })
      console.log("Window is now visible and centered")
    })

    const bounds = this.mainWindow.getBounds()
    this.windowPosition = { x: bounds.x, y: bounds.y }
    this.windowSize = { width: bounds.width, height: bounds.height }
    this.currentX = bounds.x
    this.currentY = bounds.y

    this.setupWindowListeners()
    this.isWindowVisible = true
  }

  private setupWindowListeners(): void {
    if (!this.mainWindow) return

    this.mainWindow.on("move", () => {
      if (this.mainWindow) {
        const bounds = this.mainWindow.getBounds()
        this.windowPosition = { x: bounds.x, y: bounds.y }
        this.currentX = bounds.x
        this.currentY = bounds.y
      }
    })

    this.mainWindow.on("blur", () => {
      if (this.captureMode) {
        this.exitCaptureMode()
      }
    })

    this.mainWindow.on("resize", () => {
      if (this.mainWindow) {
        const bounds = this.mainWindow.getBounds()
        this.windowSize = { width: bounds.width, height: bounds.height }
      }
    })

    this.mainWindow.on("closed", () => {
      this.mainWindow = null
      this.isWindowVisible = false
      this.windowPosition = null
      this.windowSize = null
    })
  }

  public getMainWindow(): BrowserWindow | null {
    return this.mainWindow
  }

  public isVisible(): boolean {
    return this.isWindowVisible
  }

  public hideMainWindow(): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      console.warn("Main window does not exist or is destroyed.")
      return
    }

    const bounds = this.mainWindow.getBounds()
    this.windowPosition = { x: bounds.x, y: bounds.y }
    this.windowSize = { width: bounds.width, height: bounds.height }
    if (this.captureMode) {
      this.exitCaptureMode({ refocusSafari: false, keepVisible: false })
    }
    this.mainWindow.hide()
    this.isWindowVisible = false
  }

  public showMainWindow(options: { capture?: boolean } = {}): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      console.warn("Main window does not exist or is destroyed.")
      return
    }

    if (this.windowPosition && this.windowSize) {
      this.mainWindow.setBounds({
        x: this.windowPosition.x,
        y: this.windowPosition.y,
        width: this.windowSize.width,
        height: this.windowSize.height
      })
    }

    const shouldCapture = options.capture ?? true

    if (shouldCapture) {
      this.enterCaptureMode()
    } else {
      this.captureMode = false
      this.applyPassiveMode()
      this.showWindowAccordingToMode()
    }
  }

  public toggleMainWindow(): void {
    if (this.isWindowVisible) {
      this.hideMainWindow()
    } else {
      this.showMainWindow({ capture: true })
    }
  }

  public togglePassiveMode(): void {
    if (this.captureMode) {
      this.exitCaptureMode({ keepVisible: true, refocusSafari: false })
    } else {
      this.enterCaptureMode()
    }
  }

  public showPassiveOverlay(): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      console.warn("Main window does not exist or is destroyed.")
      return
    }

    if (this.captureMode) {
      this.exitCaptureMode({ keepVisible: true, refocusSafari: false })
    }

    this.captureMode = false

    if (process.platform === "darwin") {
      this.previousAppBundleId = this.findCurrentFrontmostApp()
    }

    this.captureMode = false
    this.applyPassiveMode()
    this.showWindowAccordingToMode()
    if (!this.mainWindow.isDestroyed()) {
      this.mainWindow.webContents.send("overlay-capture-mode-change", false)
    }

    if (process.platform === "darwin") {
      this.scheduleSafariRefocus()
    }
  }

  private centerWindow(): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      return
    }

    const primaryDisplay = screen.getPrimaryDisplay()
    const workArea = primaryDisplay.workAreaSize
    
    // Get current window size or use defaults
    const windowBounds = this.mainWindow.getBounds()
    const windowWidth = windowBounds.width || 400
    const windowHeight = windowBounds.height || 600
    
    const centerX = Math.max(
      0,
      Math.min(
        workArea.width - windowWidth,
        Math.floor(workArea.width * 0.1)
      )
    )
    const desiredTop = Math.max(
      0,
      Math.min(
        Math.floor(workArea.height * 0.15),
        workArea.height - windowHeight
      )
    )
    
    this.mainWindow.setBounds({
      x: centerX,
      y: desiredTop,
      width: windowWidth,
      height: windowHeight
    })
    
    this.windowPosition = { x: centerX, y: desiredTop }
    this.windowSize = { width: windowWidth, height: windowHeight }
    this.currentX = centerX
    this.currentY = desiredTop
  }

  public centerAndShowWindow(): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      console.warn("Main window does not exist or is destroyed.")
      return
    }

    this.centerWindow()
    this.showMainWindow({ capture: true })
    
    console.log(`Window centered and shown`)
  }

  public enterCaptureMode(): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      return
    }

    if (this.captureMode) {
      return
    }

    this.captureMode = true
    this.clearSafariRefocusTimer()

    if (process.platform === "darwin") {
      this.mainWindow.setIgnoreMouseEvents(false)
      this.mainWindow.setFocusable(true)
      this.mainWindow.setAlwaysOnTop(true, "screen-saver")
      this.mainWindow.show()
      this.mainWindow.focus()
    } else {
      this.mainWindow.setAlwaysOnTop(true)
      this.mainWindow.show()
      this.mainWindow.focus()
    }

    this.mainWindow.setIgnoreMouseEvents(false)
    this.mainWindow.webContents.focus()
    this.mainWindow.webContents.send("focus-chat-input")
    this.mainWindow.webContents.send("overlay-capture-mode-change", true)
    this.isWindowVisible = true
  }

  public exitCaptureMode(options: { refocusSafari?: boolean; keepVisible?: boolean } = {}): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      return
    }

    if (!this.captureMode) {
      return
    }

    this.captureMode = false
    const keepVisible = options.keepVisible ?? true

    if (process.platform === "darwin") {
      this.mainWindow.setIgnoreMouseEvents(true, { forward: true })
      this.mainWindow.setAlwaysOnTop(true, "screen-saver")
      this.mainWindow.setFocusable(false)
      if (keepVisible) {
        this.mainWindow.showInactive()
      }
    } else {
      this.mainWindow.blur()
      this.mainWindow.setAlwaysOnTop(true)
      this.mainWindow.setIgnoreMouseEvents(false)
    }

    this.applyPassiveMode()
    this.mainWindow.webContents.send("overlay-capture-mode-change", false)
  }

  public toggleCaptureMode(): void {
    if (this.captureMode) {
      this.exitCaptureMode()
    } else {
      this.enterCaptureMode()
    }
  }

  public isCaptureModeActive(): boolean {
    return this.captureMode
  }

  private applyPassiveMode(): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      return
    }

    if (process.platform === "darwin") {
      this.mainWindow.setAlwaysOnTop(true, "screen-saver")
      this.mainWindow.setIgnoreMouseEvents(true, { forward: true })
      this.mainWindow.setFocusable(false)
    } else {
      this.mainWindow.setAlwaysOnTop(true)
      this.mainWindow.setIgnoreMouseEvents(false)
    }
  }

  private showWindowAccordingToMode(): void {
    if (!this.mainWindow || this.mainWindow.isDestroyed()) {
      return
    }

    if (this.captureMode) {
      this.enterCaptureMode()
      this.isWindowVisible = true
      return
    }

    if (process.platform === "darwin") {
      this.applyPassiveMode()
      this.mainWindow.showInactive()
    } else {
      this.mainWindow.show()
      this.mainWindow.focus()
      this.mainWindow.webContents.focus()
      this.mainWindow.setAlwaysOnTop(true)
    }

    this.isWindowVisible = true
  }

  private scheduleSafariRefocus(): void {
    if (process.platform !== "darwin") {
      return
    }

    if (this.safariRefocusTimer) {
      clearTimeout(this.safariRefocusTimer)
    }

    this.safariRefocusTimer = setTimeout(() => {
      const bundleId = this.previousAppBundleId ?? "com.apple.Safari"

      const script =
        bundleId === "com.apple.Safari"
          ? 'tell application "Safari" to activate'
          : `tell application id "${bundleId}" to activate`

      execFile("osascript", ["-e", script], (error) => {
        if (error) {
          console.warn("Failed to refocus application:", error)
        }
      })
      this.previousAppBundleId = null
      this.safariRefocusTimer = null
    }, 120)
  }

  private clearSafariRefocusTimer(): void {
    if (this.safariRefocusTimer) {
      clearTimeout(this.safariRefocusTimer)
      this.safariRefocusTimer = null
    }
  }

  private findCurrentFrontmostApp(): string | null {
    try {
      const output = execSync(
        'osascript -e "tell application \"System Events\" to get bundle identifier of first application process whose frontmost is true"',
        { encoding: "utf8" }
      )
      const bundleId = output.trim()
      if (bundleId.length > 0) {
        return bundleId
      }
    } catch (error) {
      console.warn("Unable to determine frontmost application:", error)
    }
    return null
  }

  // New methods for window movement
  public moveWindowRight(): void {
    if (!this.mainWindow) return

    const windowWidth = this.windowSize?.width || 0
    const halfWidth = windowWidth / 2

    // Ensure currentX and currentY are numbers
    this.currentX = Number(this.currentX) || 0
    this.currentY = Number(this.currentY) || 0

    this.currentX = Math.min(
      this.screenWidth - halfWidth,
      this.currentX + this.step
    )
    this.mainWindow.setPosition(
      Math.round(this.currentX),
      Math.round(this.currentY)
    )
  }

  public moveWindowLeft(): void {
    if (!this.mainWindow) return

    const windowWidth = this.windowSize?.width || 0
    const halfWidth = windowWidth / 2

    // Ensure currentX and currentY are numbers
    this.currentX = Number(this.currentX) || 0
    this.currentY = Number(this.currentY) || 0

    this.currentX = Math.max(-halfWidth, this.currentX - this.step)
    this.mainWindow.setPosition(
      Math.round(this.currentX),
      Math.round(this.currentY)
    )
  }

  public moveWindowDown(): void {
    if (!this.mainWindow) return

    const windowHeight = this.windowSize?.height || 0
    const halfHeight = windowHeight / 2

    // Ensure currentX and currentY are numbers
    this.currentX = Number(this.currentX) || 0
    this.currentY = Number(this.currentY) || 0

    this.currentY = Math.min(
      this.screenHeight - halfHeight,
      this.currentY + this.step
    )
    this.mainWindow.setPosition(
      Math.round(this.currentX),
      Math.round(this.currentY)
    )
  }

  public moveWindowUp(): void {
    if (!this.mainWindow) return

    const windowHeight = this.windowSize?.height || 0
    const halfHeight = windowHeight / 2

    // Ensure currentX and currentY are numbers
    this.currentX = Number(this.currentX) || 0
    this.currentY = Number(this.currentY) || 0

    this.currentY = Math.max(-halfHeight, this.currentY - this.step)
    this.mainWindow.setPosition(
      Math.round(this.currentX),
      Math.round(this.currentY)
    )
  }
}
