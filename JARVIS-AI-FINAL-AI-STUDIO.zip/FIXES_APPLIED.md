# JARVIS AI — Follow-up Fixes

This ZIP is a follow-up repair of the supplied JARVIS AI project. Existing Android and Web project structure is preserved.

## Changes included

1. Added `web/Dockerfile` for a multi-stage Node 22 Cloud Run deployment. The runtime image contains production dependencies, Vite build output, Express server, and shared server-side service modules.
2. Moved the pure speech-formatting utility to `web/src/services/speechFormatter.js`, added `speechFormatter.d.ts`, and updated imports so Node's built-in test runner can execute the formatter without experimental TypeScript support.
3. Improved Gemini 429 error messages in Android and Web. Quota exhaustion now directs the operator to Google AI Studio Usage and limits, project selection, billing tier, and quota reset. Temporary request bursts advise waiting and reducing request frequency.
4. Added regression tests for quota-vs-rate-limit messaging.
5. Updated deployment and verification documentation to distinguish confirmed checks from tests/builds that could not be run in this environment.

## Verification status

- 24 of 26 Web Node tests passed. Two test files were blocked at module loading because dependency installation timed out and `dotenv` (along with other runtime dependencies) was unavailable.
- JavaScript syntax checks passed for all `.js` and `.mjs` files under `web/`.
- All project JSON files parsed successfully; Web package and lockfile metadata/dependencies match.
- ZIP integrity passed.
- Full Web typecheck/build, Express integration suite, Android Gradle build/tests, Docker build, and Cloud Run deployment were not verified in this environment. See `TEST_REPORT.md`.

## Before deployment

- Set `GEMINI_API_KEY` in AI Studio Secrets or your backend hosting secret manager. Never commit a real key or put it in a `VITE_` variable.
- Set `GEMINI_MODEL=gemini-3.8-flash` on the backend if you want to pin the model explicitly.
- If `APP_ACCESS_TOKEN` is configured on the backend, enter the same token in JARVIS Web Settings.
- A provider-side Gemini quota or rate limit cannot be bypassed by code changes. Check Google AI Studio Usage and limits if HTTP 429 continues.
- Run the full Web build/tests and Android Gradle build/tests in AI Studio before deploying. This archive does not include `gradlew`, `gradlew.bat`, or `gradle-wrapper.jar`.
